# Arq Do.py
import sys
sys.path.append("C:/Users/Casa/Documents/Programacao/Python/geral/comp4")
from AnalisadorLexico import Type#, newlabel
from CodigoIntermediario import Stmt, Expr

expr = None

def init_do(x):
    global expr
    expr = x

    if x["type"] != Type.BOOL:
        x["error"]("booleano necessário no do")

def gen_do(b):
    global expr
    Expr.jumping(expr, b, 0)

