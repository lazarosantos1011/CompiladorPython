# Arq While.py
import sys
sys.path.append("C:/Users/Casa/Documents/Programacao/Python/geral/comp4")
from AnalisadorLexico import Type
from CodigoIntermediario.Node import newlabel, emitlabel, emit
from CodigoIntermediario import Expr

expr = None

def init_while(x):
    global expr, stmt
    expr = x

    # if x["type"] != Type.bool_type:
        # x["error"]("booleano necessário no while")

def gen_while(b):
    Expr.jumping(expr, 0, b)

