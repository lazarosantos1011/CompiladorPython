import sys
sys.path.append("C:/Users/Casa/Documents/Programacao/Python/geral/comp4")
from AnalisadorLexico import Lexer

file = open("C:/Users/Casa/Documents/Programacao/Python/geral/comp4/AnalisadorLexico/test.txt", "rb")
arq = []

for line in file:
    for character in line:
        arq.append(chr(character))

Lexer.cria_Lexer(arq)

while (Lexer.readch() < (len(arq)-1)):
    token = Lexer.scan()

for i in Lexer.retorno:
    print("Token: ", i)

file.close()