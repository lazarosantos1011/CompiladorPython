#Token.py

def cria_Token(tag):
        return { 'tag': tag }

def token_to_String(token):
        return str(chr(token))
